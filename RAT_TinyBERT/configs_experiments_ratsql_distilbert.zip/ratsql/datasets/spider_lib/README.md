Adapted from https://github.com/taoyds/spider in Spring 2019.
